#!/bin/bash

#PBS -l nodes=1:ppn=10
#PBS -l mem=60gb
#PBS -l walltime=12:00:00
#PBS -M f.macleod@unsw.edu.au
#PBS -m ae
#PBS -j oe

cd /srv/scratch/z5018325/DasToolALL/DasToolALL_DASTool_bins/Hightomed/Prodigal/Phylosift

java -jar /srv/scratch/z5018325/programs/BMGE-1.12/BMGE.jar -i concatenatedmarkers_endtrimmed.faa -t AA -m BLOSUM30 -g 0.5 -of concatenatedmarkers_endtrimmed_bgme.faa
