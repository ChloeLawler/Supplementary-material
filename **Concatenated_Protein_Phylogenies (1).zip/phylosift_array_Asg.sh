#!/bin/bash

#PBS -j oe
#PBS -l nodes=1:ppn=8
#PBS -l mem=12gb
#PBS -l walltime=2:00:00
#PBS -M f.macleod@unsw.edu.au
#PBS -m ae
#PBS -J 1-11

BIN_DIR=/srv/scratch/z5018325/Enrichment_Assembly/Asgards/Concat_Assembly/FullSet/Amino_Acid

cd ${BIN_DIR}

module add perl/5.28.0
module add hmmer/3.2.1
module add prodigal/2.6.3
module add pplacer/1.1.alpha19
module add raxml/8.2.12
module add fasttree/2.1.10
module add phylosift/1.0.1

BINS=("0" "bin.101.fa.faa" "bin.116.fa.faa" "bin.11.fa.faa" "bin.125.fa.faa" "bin.129.fa.faa" "bin.149.fa.faa" "bin.15.fa.faa" "bin.164.fa.faa" "bin.187.fa.faa" "bin.19.fa.faa" "bin.20.fa.faa" "bin.214.fa.faa" "bin.217.fa.faa" "bin.268.fa.faa" "bin.29.fa.faa" "bin.78.fa.faa" "bin.79.fa.faa" "bin.7.fa.faa" "bin.97.fa.faa" )
sleep $(($RANDOM % 240))

((START_NUMBER = (${PBS_ARRAY_INDEX} - 1 ) * 2 + 1))
((END_NUMBER = ${START_NUMBER} + 1))

	for i in `(seq $START_NUMBER $END_NUMBER)`
	do
	phylosift all --keep_search --output ${BINS[i]%.fasta}.1 ${BINS[i]} --debug
	done
